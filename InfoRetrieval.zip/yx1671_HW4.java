package word;
import java.io.*;
import java.math.*;
import java.util.*;
import java.lang.*;
import word.word;

public class yx1671_HW4 {
	
	static ArrayList<String> stop_word  = new ArrayList<String>(
			Arrays.asList("a","the","an","and","or","but","about","above","after","along","amid","among",
			              "as","at","by","for","from","in","into","like","minus","near","of","off","on",
			              "onto","out","over","past","per","plus","since","till","to","under","until","up",
			              "via","vs","with","that","can","cannot","could","may","might","must",
			              "need","ought","shall","should","will","would","have","had","has","having","be",
			              "is","am","are","was","were","being","been","get","gets","got","gotten",
			              "getting","seem","seeming","seems","seemed",
			              "enough", "both", "all", "your", "those", "this", "these", 
			              "their", "the", "that", "some", "our", "no", "neither", "my",
			              "its", "his","her", "every", "either", "each", "any", "another",
			              "an", "a", "just", "mere", "such", "merely", "right", "no", "not",
			              "only", "sheer", "even", "especially", "namely", "as", "more",
			              "most", "less", "least", "so", "enough", "too", "pretty", "quite",
			              "rather", "somewhat", "sufficiently", "same", "different", "such",
			              "when", "why", "where", "how", "what", "who", "whom", "which",
			              "whether", "why", "whose", "if", "anybody", "anyone", "anyplace", 
			              "anything", "anytime", "anywhere", "everybody", "everyday",
			              "everyone", "everyplace", "everything", "everywhere", "whatever",
			              "whenever", "whereever", "whichever", "whoever", "whomever", "he",
			              "him", "his", "her", "she", "it", "they", "them", "its", "their","theirs",
			              "you","your","yours","me","my","mine","I","we","us","much","and/or"));
	
	static ArrayList<Object> list = new ArrayList<Object>();	//query
	static ArrayList<Object> list2 = new ArrayList<Object>();	//abstract
	static int queryNum = 0;
	static int abstrNum = 0;

	public static HashMap<Integer, Double> sortByValue (HashMap<Integer, Double> hm){

		// create a list from elements of hashmap
		List<Map.Entry<Integer, Double>> list = new LinkedList<Map.Entry<Integer, Double>>(hm.entrySet());

		// sort the list
		Collections.sort(list, new Comparator<Map.Entry<Integer, Double> >() { 
            public int compare(Map.Entry<Integer, Double> o1, Map.Entry<Integer, Double> o2) { 
                return (o1.getValue()).compareTo(o2.getValue()); 
            } 
        }); 

        // put data from sorted list to hashmap  
        HashMap<Integer, Double> temp = new LinkedHashMap<Integer, Double>(); 
        for(Map.Entry<Integer, Double> aa : list) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 

        return temp; 

	}
	
	public static void main(String[] args) throws IOException {
		
		File inFile = null;
		
		if (0 < args.length) {
			inFile = new File(args[0]);
		} else {
			System.err.println("Invalid arguments count:" + args.length);
			System.exit(-1);
		}
		
		BufferedReader br = new BufferedReader(new FileReader(inFile));	
		
		//BufferedReader br = new BufferedReader(new FileReader("/Users/xaniles/eclipse-workspace/NLP/src/cran.qry"));
		
		String sCurrentLine = "";
		while((sCurrentLine = br.readLine()) != null) {
			
			String[] splited = sCurrentLine.split("\\s+");	//split each line into an array of strings
			
			if(splited[0].equals(".I")) {
				queryNum++;
				continue;
			} else if(splited[0].equals(".W")){
				continue;
			} else {										
				for(int i=0; i<splited.length; i++) {		//loop through the words and eliminate unwanted words
					if(stop_word.contains(splited[i])) {
						continue;
					} else if(splited[i].equals(".")) {
						continue;
					} else {
						word temp = new word(splited[i], queryNum, 0.0, 0, 0.0);
						list.add(temp);
					}
				}
			}
		}
		
		// IDF = log(number of documents / number of documents containing(t))
		int docContainT = 0;
		int occuranceT = 0;
		
		for(int i=0; i<list.size(); i++) {
			
			int prevQ = 0;
			String wordTemp = (String)((word) list.get(i)).getWord();
			int queryTemp1 = (int)((word) list.get(i)).getQueryNum();

			for(int j=0; j<list.size(); j++) {
				
				String wordTemp2 = (String)((word) list.get(j)).getWord();
				int queryTemp2 = (int)((word) list.get(j)).getQueryNum();
				
				if(wordTemp2.equals(wordTemp) && queryTemp1==queryTemp2) {
					occuranceT++;
				}
				
				if(wordTemp2.equals(wordTemp) && queryTemp2!=prevQ) {
					docContainT++;
					prevQ = queryTemp2;
				}
			}		
			
			double IDF = (double)Math.log((double)225/docContainT);
			double tfidf = occuranceT * IDF;
			((word) list.get(i)).setIdfScore(IDF);
			((word) list.get(i)).setNonStopInst(occuranceT);
			((word) list.get(i)).setTfidf(tfidf);

			docContainT = 0;	//restore for a new word
			occuranceT = 0;
		}

		// list now contains all the words from the queries -> store into the hashmap
		// HashMap<word, <queryNum, tfidf>>

		HashMap<String, HashMap<Integer, Double>> queryAll = new HashMap<>();

		for(int i=0; i<list.size(); i++){

			String wordTemp = (String)((word) list.get(i)).getWord();
			int queryTemp = (int)((word) list.get(i)).getQueryNum();
			double tfTemp = (double)((word) list.get(i)).getTfidf();

			if(queryAll.containsKey(wordTemp)){	

				HashMap<Integer, Double> hm= queryAll.get(wordTemp);

				if(hm.containsKey(queryTemp)){
					continue;
				} else {
					hm.put(queryTemp, tfTemp);
				}

			} else {

				queryAll.put(wordTemp, new HashMap<Integer, Double>());
				HashMap<Integer, Double> hm = queryAll.get(wordTemp);
				hm.put(queryTemp, tfTemp);
			}
		}

		br.close();

		// ----------------------------------------------------------------
		
		File inFile2 = new File(args[1]);
		BufferedReader br2 = new BufferedReader(new FileReader(inFile2));
		
		//BufferedReader br2 = new BufferedReader(new FileReader("/Users/xaniles/eclipse-workspace/NLP/src/cran.all.1400"));
		
		sCurrentLine = "";
		String prev = "";
		while((sCurrentLine = br2.readLine()) != null) {
			
			String[] splited = sCurrentLine.split("\\s+");
	
			if(splited[0].equals(".I")) {
				abstrNum++;
				prev = "I";
				continue;
			} else if(splited[0].equals(".W")) {
				prev = "W";
				continue;
			} else if(prev.equals("W")) {
				for(int i=0; i<splited.length; i++) {
					if(stop_word.contains(splited[i])) {
						continue;
					} else if(splited[i].equals(".")) {
						continue;
					} else if(splited[i].equals("")) {
						continue;
					} else {
						word temp = new word(splited[i], abstrNum, 0.0);
						list2.add(temp);
						continue;
					}
				}
			}
		}

		// abstractAll now contains all the abstract words with abstrNum
		// store HashMap<word, <abstrNum, occurance>> first

		HashMap<String, HashMap<Integer, Double>> abstractAll = new HashMap<>();

		for(int i=0; i<list2.size(); i++){

			String wordTemp = (String)((word) list2.get(i)).getWord();
			int absTemp = (int)((word) list2.get(i)).getAbstractNum();

			if(abstractAll.containsKey(wordTemp)){

				HashMap<Integer, Double> hm= abstractAll.get(wordTemp);

				if(hm.containsKey(absTemp)){
					hm.put(absTemp, hm.getOrDefault(absTemp, 1.0)+1);
				} else {
					hm.put(absTemp, 1.0);
				}

			} else {

				abstractAll.put(wordTemp, new HashMap<Integer, Double>());
				HashMap<Integer, Double> hm = abstractAll.get(wordTemp);
				hm.put(absTemp, 1.0);
			}
		}
		
		// IDF = log(number of documents / number of documents containing(t))
		docContainT = 0;
		double IDF = 0.0;

		// abstractAll now stores HashMap<word, <abstrNum, tfidf>> 
		for(String s: abstractAll.keySet()){

			HashMap<Integer, Double> temp = abstractAll.get(s);

			docContainT = temp.size();

			IDF = Math.log((double)1400/docContainT);

			for(Integer k: temp.keySet()){

				double occurance = temp.get(k);

				double tfidf = (double)occurance * IDF;

				temp.put(k, tfidf);
			}
		}

		//System.out.println(abstractAll);

		br2.close();

		// ----------------------------------------------------------------

		FileWriter output = new FileWriter("output.txt");

		Double currTf = 0.0;
		ArrayList<Double> currQuery = new ArrayList<Double>();
		ArrayList<Double> currAbstract = new ArrayList<Double>();
		ArrayList<String> currWords = new ArrayList<String>();			// store all the words in the current query
		HashMap<Integer, Double> map = new HashMap<Integer, Double>();	// <abstraNum, similarity>

		for(int i=1; i<=225; i++){

			for(String s: queryAll.keySet()){							// s: all the words (不重复)

				HashMap<Integer, Double> temp = queryAll.get(s);		// temp: all the query ID that contain the current word

				if(temp.containsKey(i)){								// if the current i is one of the IDs

					currWords.add(s);
					currTf = temp.get(i);								// queryTf: the tfidf of the current word in query i 
					currQuery.add(currTf);

				} else {												// if the current i is not in the key, continue

					continue;
				}	

			} // 走完这个loop: currWords和currQuery里都存了对应的word和他们的tfidf

			//System.out.println(currWords);

			for(int j=1; j<=1400; j++) {								// go through each abstract

				for(int k=0; k<currWords.size(); k++){					// go through each word in the current query

					if(abstractAll.containsKey(currWords.get(k))){		// if abstractAll contain this word -> 算ID

						HashMap<Integer, Double> temp2 = abstractAll.get(currWords.get(k));	 // temp2: all the abstract ID that contain the current word

						if(temp2.containsKey(j) && !temp2.isEmpty()){	// if the current j is one of the IDs				

							currTf = temp2.get(j);
							currAbstract.add(currTf);

						} else {

							currAbstract.add(0.0);

						}

					} else {

						currAbstract.add(0.0);

					}
				}

				// 走完这个loop: currAbstract里存了对应的tfidf -> 开始算cosine
				double numerator = 0.0;
				double denominator = 0.0;
				double denominator1 = 0.0;
				double denominator2 = 0.0;
				double similarity = 0.0;

				for(int x=0; x<currWords.size(); x++){
					//System.out.println(currAbstract.get(x));
					numerator += (double)currQuery.get(x) * (double)currAbstract.get(x);
					denominator1 += (double)Math.pow(currQuery.get(x), 2);
					denominator2 += (double)Math.pow(currQuery.get(x), 2);
				}

				denominator = (double)Math.sqrt(denominator1 * denominator2);
				similarity = (double)numerator/denominator;

				map.put(j, similarity);

				// restore currAbstract
				currAbstract.clear();
			}

			// sort the hashmap
			Map<Integer, Double> map1 = sortByValue(map);

			// reverse the order from highest to lowest
			ArrayList<Integer> keys = new ArrayList<Integer>(map1.keySet());

			for(int a=keys.size()-1; a>=0; a--){
				Double simiTemp = map1.get(keys.get(a));
				output.write(i + " " + keys.get(a) + " " + simiTemp + "\n");
			}

			// restore currWords currQuery and currSimilarity
			currWords.clear();
			currQuery.clear();
			map.clear();
			map1.clear();
		}

	}

}
