import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class dollar_program {
	public static void main(String args[]) throws Exception {
		
		//read file from the command line
		File inFile = null;
		
		if (0 < args.length) {
		   inFile = new File(args[0]);
		} else {
		   System.err.println("Invalid arguments count:" + args.length);
		   System.exit(0);
		}
	
		BufferedReader br = new BufferedReader(new FileReader(inFile));
		FileWriter output = new FileWriter("dollar_output.txt");
		
		//Pattern patternObj = Pattern.compile("[a-zA-Z0-9]+\\s(hundred|thousand|million|billion)*\\s(dollars{0,1}|cents{0,1})");
		//Pattern patternObj2 = Pattern.compile("\\$[0-9\\.,]+(\\s)*(million|billion|thousand)*");

		String word = "[a-zA-z]+\\s((hundred|thousand|million|billion)*\\s)?(dollars?|cents?)";
		String digit = "[0-9\\.,]+\\s((hundred|thousand|million|billion)*\\s)?(dollars?|cents?)";

		String withoutSign = '(' + word + ")|(" + digit + ')';
		String withSign = "\\$[0-9\\.,]+(\\s)*(thousand|million|billion)*";
		
		//regExp
		Pattern patternObj = Pattern.compile('(' + withoutSign + ")|(" + withSign + ')');

		String sCurrentLine;
		while((sCurrentLine = br.readLine()) != null) {	//read the file line by line
			
			Matcher matcherObj = patternObj.matcher(sCurrentLine);
			boolean matchFound = matcherObj.find();
		
			if(matchFound) {
				try {
					output.write(matcherObj.group()+"\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			/*finally {
				try {
					if(br!=null)
						br.close();
				} catch(IOException ex) {
					ex.printStackTrace();
				}
			}*/	
		}

		br.close();
		output.close();	

	}
}
