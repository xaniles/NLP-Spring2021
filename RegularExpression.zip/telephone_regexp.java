import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class telephone_regexp {
	public static void main(String args[]) throws Exception {
		
		//read file from the command line
		File inFile = null;
		
		if (0 < args.length) {
		   inFile = new File(args[0]);
		} else {
		   System.err.println("Invalid arguments count:" + args.length);
		   System.exit(0);
		}
	
		BufferedReader br = new BufferedReader(new FileReader(inFile));
		FileWriter output = new FileWriter("telephone_output.txt");

		//String a = "(d{3}\\-){2}\\d{4}";
		//String b = "\\(\\d{3}\\)\\s?\\d{3}-\\d{4}";
		String a = "\\([2-9][0-9]{2}\\)\\s?[0-9]{3}-[0-9]{4}";
		String b = "[2-9][0-9]{2}-[0-9]{3}-[0-9]{4}";
		String c = "\\s[0-9]{3}-[0-9]{4}";
		
		//regularExpression: xxx-xxx-xxxx|(xxx)xxx-xxxx|xxx-xxxx
		Pattern patternObj = Pattern.compile('(' + a + ")|(" + b + ")|(" + c + ')');

		String sCurrentLine;
			
		while((sCurrentLine = br.readLine()) != null) {	//read the file line by line
			
			Matcher matcherObj = patternObj.matcher(sCurrentLine);
			boolean matchFound = matcherObj.find();
		
			if(matchFound) {
				try {
					output.write(matcherObj.group()+"\n");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		br.close();
		output.close();	

	}
}
