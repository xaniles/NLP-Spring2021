package word;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import word.word;

public class yx1671_HW5 {
	
	static ArrayList<Object> list = new ArrayList<Object>();
	
	public static void main(String[] args) throws IOException {
		
		// import from the command line
		File inFile = null;
		if(0 < args.length) {
			inFile = new File(args[0]);
		} else {
			System.err.println("Invalid arguments count:" + args.length);
			System.exit(-1);
		}
		
		BufferedReader br = new BufferedReader(new FileReader(inFile));
		//BufferedReader br = new BufferedReader(new FileReader("/Users/xaniles/Desktop/WSJ_CHUNK_FILES/WSJ_02-21.pos-chunk"));
		
		String sCurrentLine = "";
		while((sCurrentLine = br.readLine()) != null) {
			
			String word = "";
			String pos = "";
			String bio = "";
			
			// split the lines
			String[] splited = sCurrentLine.split("\\s+");
			if(splited.length > 1) {
				word = splited[0];
				pos = splited[1];
				//bio = splited[2];
			}
			
			// add new objects
			word temp = new word(word, pos, bio, "", "", "", "", "", "", "", "", "", "", "", "");
			list.add(temp);
		}
		
		br.close();
		
		String word;
		String pos;
		String bio;
		
		String pre_word;
		String pre_pos;
		String pre_bio;
		
		String pre_pre_word;
		String pre_pre_pos;
		String pre_pre_bio;
		
		String next_word;
		String next_pos;
		String next_bio;
		
		String next_next_word;
		String next_next_pos;
		String next_next_bio;
		
		// handle OutOfBound case (index1)
		next_word = ((word) list.get(2)).getWord();
		next_pos = ((word) list.get(2)).getPos();
		next_bio = ((word) list.get(2)).getBio();
		
		next_next_word = ((word) list.get(3)).getWord();
		next_next_pos = ((word) list.get(3)).getPos();
		next_next_bio = ((word) list.get(3)).getBio();
		
		((word) list.get(1)).setNext_word(next_word);
		((word) list.get(1)).setNext_pos(next_pos);
		((word) list.get(1)).setNext_bio(next_bio);
		
		((word) list.get(1)).setNext_next_word(next_next_word);
		((word) list.get(1)).setNext_next_pos(next_next_pos);
		((word) list.get(1)).setNext_next_bio(next_next_bio);
		
		// go over the arraylist
		for(int i=2; i<list.size()-2; i++) {
			
			word = ((word) list.get(i)).getWord();
			pos = ((word) list.get(i)).getPos();
			bio = ((word) list.get(i)).getBio();
			
			pre_word = ((word) list.get(i-1)).getWord();
			pre_pos = ((word) list.get(i-1)).getPos();
			pre_bio = ((word) list.get(i-1)).getBio();
			
			pre_pre_word = ((word) list.get(i-2)).getWord();
			pre_pre_pos = ((word) list.get(i-2)).getPos();
			pre_pre_bio = ((word) list.get(i-2)).getBio();
			
			next_word = ((word) list.get(i+1)).getWord();
			next_pos = ((word) list.get(i+1)).getPos();
			next_bio = ((word) list.get(i+1)).getBio();
			
			next_next_word = ((word) list.get(i+2)).getWord();
			next_next_pos = ((word) list.get(i+2)).getPos();
			next_next_bio = ((word) list.get(i+2)).getBio();
			
			// skip the blank line
			if(word.equals("")) {
				continue;
			}
			
			// at the beginning of each sentence: omit features of 2 words back
			if(pre_word.equals("")) {
				((word) list.get(i)).setNext_word(next_word);
				((word) list.get(i)).setNext_pos(next_pos);
				((word) list.get(i)).setNext_bio(next_bio);
				
				((word) list.get(i)).setNext_next_word(next_next_word);
				((word) list.get(i)).setNext_next_pos(next_next_pos);
				((word) list.get(i)).setNext_next_bio(next_next_bio);
				continue;
			}
			
			// at the second beginning of each sentence: omit features of 1 word back
			if(pre_pre_word.equals("")) {
				((word) list.get(i)).setPre_word(pre_word);
				((word) list.get(i)).setPre_pos(pre_pos);
				((word) list.get(i)).setPre_bio(pre_bio);
				
				((word) list.get(i)).setNext_word(next_word);
				((word) list.get(i)).setNext_pos(next_pos);
				((word) list.get(i)).setNext_bio(next_bio);
				
				((word) list.get(i)).setNext_next_word(next_next_word);
				((word) list.get(i)).setNext_next_pos(next_next_pos);
				((word) list.get(i)).setNext_next_bio(next_next_bio);
				continue;
			}
			
			// at the end of each sentence: omit features of 2 words forward
			if(next_word.equals("")) {
				((word) list.get(i)).setPre_word(pre_word);
				((word) list.get(i)).setPre_pos(pre_pos);
				((word) list.get(i)).setPre_bio(pre_bio);
				
				((word) list.get(i)).setPre_pre_word(pre_pre_word);
				((word) list.get(i)).setPre_pre_pos(pre_pre_pos);
				((word) list.get(i)).setPre_pre_bio(pre_pre_bio);
				continue;
			}
			
			// at the second end of each sentence: omit features of 1 word forward
			if(next_next_word.equals("")) {
				((word) list.get(i)).setNext_word(next_word);
				((word) list.get(i)).setNext_pos(next_pos);
				((word) list.get(i)).setNext_bio(next_bio);
				
				((word) list.get(i)).setPre_word(pre_word);
				((word) list.get(i)).setPre_pos(pre_pos);
				((word) list.get(i)).setPre_bio(pre_bio);
				
				((word) list.get(i)).setPre_pre_word(pre_pre_word);
				((word) list.get(i)).setPre_pre_pos(pre_pre_pos);
				((word) list.get(i)).setPre_pre_bio(pre_pre_bio);
				continue;
			}

			// handle normal cases
			((word) list.get(i)).setNext_word(next_word);
			((word) list.get(i)).setNext_pos(next_pos);
			((word) list.get(i)).setNext_bio(next_bio);
			
			((word) list.get(i)).setNext_next_word(next_next_word);
			((word) list.get(i)).setNext_next_pos(next_next_pos);
			((word) list.get(i)).setNext_next_bio(next_next_bio);
			
			((word) list.get(i)).setPre_word(pre_word);
			((word) list.get(i)).setPre_pos(pre_pos);
			((word) list.get(i)).setPre_bio(pre_bio);
			
			((word) list.get(i)).setPre_pre_word(pre_pre_word);
			((word) list.get(i)).setPre_pre_pos(pre_pre_pos);
			((word) list.get(i)).setPre_pre_bio(pre_pre_bio);
				
		}
		
		FileWriter output = new FileWriter("test.feature");
		for(int j=0; j<list.size(); j++) {
			String output_line = "";

			if(((word) list.get(j)).getWord().equals("")){
				output.write("\n");
				continue;
			}

			output_line = ((word) list.get(j)).getWord() + "\t"
			+ "POS=" + ((word) list.get(j)).getPos() + "\t"
			+ "pre_WORD=" + ((word) list.get(j)).getPre_word() + "\t"
			+ "pre_POS=" + ((word) list.get(j)).getPre_pos() + "\t"
			//+ "pre_BIO=" + ((word) list.get(j)).getPre_bio() + "\t"
			+ "pre_pre_WORD=" + ((word) list.get(j)).getPre_pre_word() + "\t"
			+ "pre_pre_POS=" + ((word) list.get(j)).getPre_pre_pos() + "\t"
			//+ "pre_pre_BIO=" + ((word) list.get(j)).getPre_pre_bio() + "\t"
			+ "next_WORD=" + ((word) list.get(j)).getNext_word() + "\t"
			+ "next_POS=" + ((word) list.get(j)).getNext_pos() + "\t"
			//+ "next_BIO=" + ((word) list.get(j)).getNext_bio() + "\t"
			+ "next_next_WORD=" + ((word) list.get(j)).getNext_next_word() + "\t"
			+ "next_next_POS=" + ((word) list.get(j)).getNext_next_pos();
			//+ "next_next_BIO=" + ((word) list.get(j)).getNext_next_bio();
			//+ ((word) list.get(j)).getBio();
			
			output.write(output_line + "\n");
			
		}
		
		output.close();
	
	}
		
}
